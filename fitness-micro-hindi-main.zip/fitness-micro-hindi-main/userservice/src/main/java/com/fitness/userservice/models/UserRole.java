package com.fitness.userservice.models;

public enum UserRole {
    USER, ADMIN
}
